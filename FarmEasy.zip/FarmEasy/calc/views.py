from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'index.html')

def farmer(request):
    return render(request,'farmer.html')

def tourist(request):
    return render(request,'tourist.html')

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from googletrans import Translator
import pandas as pd
import joblib
import os
import requests
import json

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, '..', 'SavedNotebooks')

rf_model = joblib.load(os.path.join(MODEL_DIR, 'rf_model.pkl'))
label_encoder_soil = joblib.load(os.path.join(MODEL_DIR, 'label_encoder_soil.pkl'))
label_encoder_crop = joblib.load(os.path.join(MODEL_DIR, 'label_encoder_crop.pkl'))
label_encoder_fertilizer = joblib.load(os.path.join(MODEL_DIR, 'label_encoder_fertilizer.pkl'))

translator = Translator()

def translate_text(text, target_language='en'):
    try:
        translated_text = translator.translate(text, dest=target_language).text
        return translated_text
    except Exception as e:
        return f"Error in translation: {str(e)}"

@csrf_exempt
def translate_text_view(request):
    if request.method == "POST":
        data = json.loads(request.body)
        speech_text = data.get('speech_text', '')

        # Translate the recognized text
        translated_text = translate_text(speech_text)

        return JsonResponse({'translated_text': translated_text})

    return JsonResponse({'error': 'Invalid request method'}, status=400)

import os
import pandas as pd
from django.conf import settings

# Properly construct the file path
fertilizer_data_path = os.path.join(settings.BASE_DIR,'static', 'data', 'Fertilizer Quant.csv')

# Load the CSV file
fertilizer_data = pd.read_csv(fertilizer_data_path)

@csrf_exempt
def farmer_pred(request):
    result = None
    description = None
    nutrient_composition = None
    recommended_quantity = None
    application_guidelines = None
    yield_improvement = None
    
    if request.method == 'POST':
        try:
            # Handle form data
            soil_type = request.POST.get('soil_type', 'Sandy')
            crop_type = request.POST.get('crop_type', 'Maize')
            city = request.POST.get('city', 'Hyderabad')

            # Translate Telugu text to English
            soil_type = translate_text(soil_type)
            crop_type = translate_text(crop_type)

            # Default values for nutrients and moisture
            moisture = 50
            nitrogen = 20
            potassium = 10
            phosphorous = 15

            # Fetch weather data
            api_key = '4c38c70ac3a344c5bfa40207240809'
            url = f'http://api.weatherapi.com/v1/current.json?key={api_key}&q={city}&aqi=no'
            response = requests.get(url)
            if response.status_code != 200:
                raise Exception(f"Weather API request failed with status code {response.status_code}")

            weather_data = response.json()
            temperature = weather_data['current'].get('temp_c', 25)
            humidity = weather_data['current'].get('humidity', 50)

            # Prepare input data
            input_data = pd.DataFrame({
                'Soil Type': [soil_type],
                'Crop Type': [crop_type],
                'Temparature': [temperature],
                'Humidity ': [humidity],
                'Moisture': [moisture],
                'Nitrogen': [nitrogen],
                'Potassium': [potassium],
                'Phosphorous': [phosphorous]
            })

            # Encode input data
            input_data['Soil Type'] = label_encoder_soil.transform(input_data['Soil Type'])
            input_data['Crop Type'] = label_encoder_crop.transform(input_data['Crop Type'])

            # Predict
            predicted_fertilizer_encoded = rf_model.predict(input_data)
            predicted_fertilizer = label_encoder_fertilizer.inverse_transform(predicted_fertilizer_encoded)
            result = predicted_fertilizer[0]

            # Fetch details from CSV
            description_row = fertilizer_data[fertilizer_data['Fertilizer Name'] == result]
            if not description_row.empty:
                description = description_row['Description'].values[0]
                nutrient_composition = description_row['Nutrient Composition (N-P-K)'].values[0]
                recommended_quantity = description_row['Recommended Quantity'].values[0]
                application_guidelines = description_row['Application Guidelines'].values[0]
                yield_improvement = description_row['Expected Yield Improvement'].values[0]
            else:
                description = "Description not available."
                nutrient_composition = "Not available"
                recommended_quantity = "Not available"
                application_guidelines = "Not available"
                yield_improvement = "Not available"

        except Exception as e:
            result = f"Error: {e}"
            description = nutrient_composition = recommended_quantity = application_guidelines = yield_improvement = None

    return render(request, 'pred.html', {
        'result': result,
        'description': description,
        'nutrient_composition': nutrient_composition,
        'recommended_quantity': recommended_quantity,
        'application_guidelines': application_guidelines,
        'yield_improvement': yield_improvement
    })
    
    
def tourist_centres(request):
    return render(request,'centres.html')

def micro_fin(request):
    return render(request,'micro.html')

def farmer_sell(request):
    return render(request,'sell.html')

def farmer_buy(request):
    return render(request,'seeds.html')

def farmer_tools(request):
    return render(request,'tools.html')

def farmer_machine(request):
    return render(request,'machine.html')

def farmer_fertilizer(request):
    return render(request,'fertilizers.html')

def garden(request):
    return render(request,'garden.html')

def knowledge(request):
    return render(request,'resources.html')

def tourist_buy(request):
    return render(request,'groceries.html')
 # Assuming you created a Django form for the model

from django.shortcuts import render, redirect
from .models import AgriculturalTourBooking

def tourist_book(request):
    if request.method == 'POST':
        # Get data from the POST request
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        preferred_date = request.POST.get('preferred_date')
        group_size = request.POST.get('group_size')
        tour_type = request.POST.get('tour_type')
        special_requirements = request.POST.get('special_requirements')

        # Create and save the new tour booking
        booking = AgriculturalTourBooking(
            full_name=full_name,
            email=email,
            phone=phone,
            preferred_date=preferred_date,
            group_size=group_size,
            tour_type=tour_type,
            special_requirements=special_requirements
        )
        booking.save()

        # Redirect to a success page or show a success message
        return render(request, 'form.html', {'booking': booking})

    return render(request, 'form.html')





def farmer_scheme(request):
    return render(request,'scheme.html')